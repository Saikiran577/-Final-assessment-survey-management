package com.example.Survey.management;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class mismanagement {
    @Autowired
    private surveymanagemntRepository repo;

    public List<mismanagement> listAll() {
        return repo.findAll();
    }

    public void save(mismanagement product) {
        repo.save(product);
    }

    public mismanagement get(long id) {
        return (mismanagement) repo.findById(id);
    }

    public void delete(long id) {
        repo.deleteById(id);
    }
}
