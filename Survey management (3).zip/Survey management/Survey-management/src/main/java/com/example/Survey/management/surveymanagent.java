package com.example.Survey.management;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.List;

@Entity
public class surveymanagent {
    private long date;
    private String name;
    private String test;

    protected surveymanagent() {
    }

    public surveymanagent(long date, String name, String test) {
        super();
        this.date = date;
        this.name = name;
        this.test = test;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public void save(surveymanagent product) {
    }

    public List<surveymanagent> listAll() {
        return null;
    }

    public surveymanagent get(int id) {
        return null;
    }

    public void delete(int id) {
    }
}




